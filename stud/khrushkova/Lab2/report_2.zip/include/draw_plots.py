import math
import numpy as np
import matplotlib.pyplot as plt


figure, axes = plt.subplots(1)


x = np.linspace(0, 3, 500)
y = list(map(lambda i: (i+1)**2 + 8, x))
axes.plot(x, y)

x = np.linspace(0, 4, 500)
y = list(map(lambda i: 6*math.sqrt(i+3), x))
axes.plot(x, y)


# plt.xticks(np.arange(min(*x1, *x2)-1, max(*x1, *x2)+1, 1.0))
# plt.yticks(np.arange(min(*x1, *x2)-1, max(*x1, *x2)+1, 1.0))
# axes.set_aspect(1)
plt.grid()
plt.show()
